Getting started with your new Graylog plugin
============================================

Welcome to your new Graylog plugin!

Please refer to https://docs.graylog.org/docs/plugins for documentation on how to write
plugins for Graylog.

